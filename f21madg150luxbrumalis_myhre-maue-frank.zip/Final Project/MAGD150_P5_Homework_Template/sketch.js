var beaver;
var coyote;
var log;
var beaverx = 100;
var beavery = 600;
var health = 600;
var healthbar;
var beaverspritesheet;
var beavershootspritesheet;
var beaverwalkrspritesheet;
var logspritesheet;
var logdeadspritesheet;
var beaverani;
var beavershoot;
var beaverd;
var logani;
var logdie;
var bullets;
var logdies = 500;
var coyotedies = 500;
var healthpack;
var healthpacks;
var healthpspritesheet;
var healthp;
var backg;
var healthbspritesheet;
var healthb;
var healthbani
var coyotespritesheet;
var coyoteani
var wallspritesheet;
var dispenserspritesheet;
var platespritesheet;
var boxspritesheet;
var teleporterspritesheet;
var doorspritesheet;
var wall;
var dispenser;
var plate;
var box;
var teleporter
var door;
var wallani;
var dispenserani;
var plateani;
var boxani;
var teleporterani;
var doorani;
var deathscreenspritesheet;
var deathscreenani;
var textfonty
var gameovertextspritesheet;
var restarttextspritesheet;
var gameoverani;
var restartani;
var pressureact = 0;
var platesss
var win = 0;
var winspritesheet;
var winscreenani;

function preload(){
  beaverspritesheet = loadSpriteSheet('walk.png',128,128,1);
  beavershootspritesheet = loadSpriteSheet('shoot.png',128,128,3);
  logspritesheet = loadSpriteSheet('logmove.png',128,128,7);
  logdeadspritesheet = loadSpriteSheet('logdead.png',128,128,1);
  beaverwalkrspritesheet = loadSpriteSheet('walkright.png',128,128,1);
  healthpspritesheet = loadSpriteSheet('healthp.png',128,128,1);
  healthbspritesheet = loadSpriteSheet('healthb.png',100,100,9);
  coyotespritesheet = loadSpriteSheet('coyote.png',128,128,9);
  wallspritesheet = loadSpriteSheet('wall.png',32,128,1);
  dispenserspritesheet = loadSpriteSheet('dispenser.png',32,128,1);
  platespritesheet = loadSpriteSheet('plate.png',32,32,1);
  boxspritesheet = loadSpriteSheet('box.png',32,32,1);
  teleporterspritesheet = loadSpriteSheet('teleporter.png',256,160,1);
  doorspritesheet = loadSpriteSheet('door.png',32,128,1);
  deathscreenspritesheet = loadSpriteSheet('dead.png',1200,1200,1);
  gameovertextspritesheet = loadSpriteSheet('gameover.png',1000,500,1);
  restarttextspritesheet = loadSpriteSheet('restart.png',600,400,1);
  winspritesheet = loadSpriteSheet('open.png',1200,1200,1);

  beaverani = loadAnimation(beaverspritesheet);
  beavershoot = loadAnimation(beavershootspritesheet);
  beaverd = loadAnimation(beaverwalkrspritesheet);
  logani = loadAnimation(logspritesheet);
  logdie = loadAnimation(logdeadspritesheet);
  healthp = loadAnimation(healthpspritesheet);
  healthb = loadAnimation(healthbspritesheet);
  coyoteani = loadAnimation(coyotespritesheet);
  wallani = loadAnimation(wallspritesheet);
  dispenserani = loadAnimation(dispenserspritesheet);
  plateani = loadAnimation(platespritesheet);
  boxani = loadAnimation(boxspritesheet);
  teleporterani = loadAnimation(teleporterspritesheet);
  doorani = loadAnimation(doorspritesheet);
  deathscreenani = loadAnimation(deathscreenspritesheet);
  gameoverani = loadAnimation(gameovertextspritesheet);
  restartani = loadAnimation(restarttextspritesheet);
  winscreenani = loadAnimation(winspritesheet);

  textfonty = loadFont('BIT.otf');
}

function setup() {
  createCanvas(1200,1312);
  backg = loadImage('background.png');
  bullets = new Group();
  logs = new Group();
  coyotes = new Group();
  healthpacks = new Group();
  walls = new Group();
  dispenserbullets = new Group();
  plates = new Group();
  doors = new Group();
  bulletes = new Group();
  collectables = new Group();


  teleporter = createSprite(1900,600,100,100);
  teleporter.rotation = 90;
  teleporter.addAnimation('wallsprite',teleporterani);
  var collectable = createSprite(75,75,10,10)
  collectable.shapeColor = color(255,255,100);
  collectables.add(collectable);
  var collectable = createSprite(1100,1100,10,10)
  collectable.shapeColor = color(255,255,100);
  collectables.add(collectable);
  var collectable = createSprite(75,1100,10,10)
  collectable.shapeColor = color(255,255,100);
  collectables.add(collectable);
  var collectable = createSprite(1100,75,10,10)
  collectable.shapeColor = color(255,255,100);
  collectables.add(collectable);
  healthbani = createSprite(250,1240,100,100);
  healthbani.addAnimation('heartbeat',healthb);
  wallgeneration();
  
  dispenser = createSprite(448,16,100,100);
  dispenser.addAnimation('wallsprite',dispenserani);
  dispenser.rotation = 90

  platesss = createSprite(200,300,32,32);
  platesss.addAnimation('mmplate', plateani);

  plate = createSprite(768,432,100,100);
  platepreset();
  plate = createSprite(768,464,100,100);
  platepreset();
  plate = createSprite(768,768,100,100);
  platepreset();
  plate = createSprite(768,736,100,100);
  platepreset();
  plate = createSprite(432,536,100,100);
  platepreset();
  plate = createSprite(432,568,100,100);
  platepreset();
  plate = createSprite(432,664,100,100);
  platepreset();
  plate = createSprite(432,632,100,100);
  platepreset();
  box = createSprite(1050,250,100,100);
  box.addAnimation('wallsprite',boxani);

  door = createSprite(592,400,100,100);
  door.rotation = 90;
  doorpreset();
  door = createSprite(592,800,100,100);
  door.rotation = 90;
  doorpreset();
  coyotegeneration();
  loggeneration();
  beaver = createSprite(beaverx,beavery,100,100);
  beaver.addAnimation('walkright',beaverd);
  beaver.changeAnimation('walkright');
  beaver.addAnimation('shoot',beavershoot);
  }

function draw() {

  dead();
  background(backg);
  rectMode(CENTER);  
  fill(150,150,150)
  rect(600,1240,600,20)

  rectMode(CENTER);  
  fill(0,255,0)
  rect(600,1240,health,20)
  if(keyDown('w')){
    var bdir = beaver.rotation;
    beaver.limitSpeed(2);
    beaver.addSpeed(0.1,bdir);
    beaver.changeAnimation('walkright')
  }
  if(keyWentUp('w')){
    beaver.setSpeed(0,bdir);
  }
  if(keyDown('a')){
    beaver.rotation -= 4;
    beaver.changeAnimation('walkright')
  }
  if(keyDown('s')){
    var bdi = beaver.rotation;
    beaver.limitSpeed(0);
    beaver.addSpeed(-2,bdi);
    beaver.changeAnimation('walkright')    
  }
  if(keyDown('d')){
    beaver.rotation += 4;
    beaver.changeAnimation('walkright')
    
  }
  if(keyWentUp('s')){
    beaver.setSpeed(0,bdi);
  }

  wincondition();
  box.overlap(platesss,shutoff);

  beaver.overlap(collectables, collect);
  beaver.setCollider("rectangle",0,0,88,88)
  coyotes.overlap(beaver,healthfunct)
  logs.overlap(beaver,healthfunct)
  coyotes.overlap(bullets,damage2)
  logs.overlap(bullets,damage1)
  healthpacks.overlap(beaver,healthadd)
  for (let i = 0; i < coyotes.length; i++) {
    coyotes[i].limitSpeed(0.5);
    coyotes[i].attractionPoint(0.5, beaver.position.x, beaver.position.y);
  }
  for (let i = 0; i < logs.length; i++) {
    logs[i].limitSpeed(0.5);
    logs[i].attractionPoint(0.5, beaver.position.x, beaver.position.y);
  }
  walls.displace(box);
  walls.displace(logs);
  walls.displace(coyotes);
  walls.displace(beaver);
  bullets.collide(walls);
  doors.displace(box);
  doors.displace(logs);
  doors.displace(coyotes);
  doors.displace(beaver);
  bullets.collide(doors);
  if(pressureact == 0){
    dispenseraction();
  }
  bulletes.overlap(beaver,healthfunct);
  box.collide(beaver);
  plates.overlap(beaver,dooraction);
  

  if(health > 600){
    health = 600;
  }

  dead();
  drawSprites();

}

function wincondition(){
  if(win == 4){
    var winscreen = createSprite(600,600,1200,1200);
    winscreen.addAnimation('winscr',winscreenani);
    win = win+1
  }
}


function collect(collector, collected)
{
  win = win + 1
  collected.remove();
}


function healthfunct() {
  if(true){
    health = health - 3;
  }
  if(false){
    health = health;
  }
}
function dead(){
  if(health <= 0){
    health = 0;
    var deathscreen = createSprite(600,600,1200,1200);
    deathscreen.addAnimation('deathscr',deathscreenani);
    var gameover = createSprite(600,400,1000,500);
    gameover.addAnimation('gameovrtxt',gameoverani);
    var restart = createSprite(600,900,600,400);
    restart.addAnimation('restrttxt',restartani);

  }
}

function mousePressed(){
    beaver.changeAnimation('walkright');
    var bullet = createSprite(beaver.position.x, beaver.position.y,5,5);
    bullet.shapeColor = color(0,0,255);
    bullet.setSpeed(10+beaver.getSpeed(),  beaver.rotation);
    bullet.life = 30;
    bullets.add(bullet);
}

function damage1(){
  if(true){
    logdies = logdies -50;
    if(logdies <= 0){
      for (let i = 0; i < logs.length; i++) {
        logs[i].remove();
      }
      logdies = 500;
      healthpack = createSprite(log.position.x,log.position.y,30,20);
      healthpack.addAnimation('heal',healthp);
      healthpack.setCollider('rectangle',0,0,30,20);
      healthpack.life = 150;
      healthpacks.add(healthpack);
    }
  }
}

function damage2(){
  if(true){
    coyotedies = coyotedies -50;
    if(coyotedies <= 0){
      for (let i = 0; i < coyotes.length; i++) {
        coyotes[i].remove();
      }
      coyotedies = 500;
      healthpack = createSprite(coyote.position.x,coyote.position.y,30,20);
      healthpack.addAnimation('heal',healthp);
      healthpack.setCollider('rectangle',0,0,30,20);
      healthpack.life = 150;
      healthpacks.add(healthpack);
    }
  }
}

function healthadd(){
  healthpack.remove();
  health = health + 100;
}

function coyotepreset(){
  coyote.addAnimation('coyoteanim',coyoteani);
  coyote.setCollider('rectangle',0,0,115,32);
  coyote.rotateToDirection = true;
  coyote.limitSpeed(1);
  coyotes.add(coyote);
}

function logpreset(){
  log.addAnimation('loganim',logani);
  log.setCollider("circle",0,0,32)
  log.rotateToDirection = true;
  log.limitSpeed(1);
  logs.add(log);
}

function wallpreset(){
  wall.addAnimation('wallsprite',wallani);
  wall.immovable = true;
  walls.add(wall);
}

function platepreset(){
  plate.addAnimation('wallsprite',plateani);
  plate.immovable = true;
  plates.add(plate);
}

function doorpreset(){
  door.addAnimation('wallsprite',doorani);
  door.immovable = true;
  doors.add(door);
}

function dispenseraction(){
    var bullete = createSprite(dispenser.position.x, dispenser.position.y+3,5,5);
    bullete.shapeColor = color(255,255,255);
    bullete.velocity.y = 10;
    bullete.life = 30;
    bulletes.add(bullete);
}

function shutoff(){
  pressureact = pressureact + 1;
  bulletes.removeSprites();
}
function dooraction(){
  if(true){

    doors.removeSprites();
  }
}

function coyotegeneration(){
  coyote = createSprite(580,300,20,100);
  coyotepreset();
  coyote = createSprite(580,280,20,100);
  coyotepreset();
  coyote = createSprite(580,260,20,100);
  coyotepreset();
  coyote = createSprite(580,240,20,100);
  coyotepreset();
  coyote = createSprite(580,220,20,100);
  coyotepreset();
  coyote = createSprite(580,200,20,100);
  coyotepreset();
  coyote = createSprite(580,180,20,100);
  coyotepreset();
  coyote = createSprite(580,160,20,100);
  coyotepreset();
  coyote = createSprite(580,1000,20,100);
  coyotepreset();
  coyote = createSprite(580,980,20,100);
  coyotepreset();
  coyote = createSprite(580,960,20,100);
  coyotepreset();
  coyote = createSprite(580,940,20,100);
  coyotepreset();
  coyote = createSprite(580,920,20,100);
  coyotepreset();
  coyote = createSprite(580,900,20,100);
  coyotepreset();
  coyote = createSprite(580,880,20,100);
  coyotepreset();
  coyote = createSprite(580,860,20,100);
  coyotepreset();
  coyote = createSprite(200,200,20,100);
  coyotepreset();
}

function loggeneration(){
  log = createSprite(1100,300,20,100);
  logpreset();
  log = createSprite(1100,300,20,100);
  logpreset();
  log = createSprite(300,300,20,100);
  logpreset();
  log = createSprite(200,300,20,100);
  logpreset();
  log = createSprite(900,300,20,100);
  logpreset();

}


function wallgeneration(){
  wall = createSprite(64,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(192,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(320,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(448,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(576,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(704,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(832,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(960,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1088,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1216,16,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1184,64,100,100);
  wallpreset();
  wall = createSprite(1184,192,100,100);
  wallpreset();
  wall = createSprite(1184,320,100,100);
  wallpreset();
  wall = createSprite(1184,448,100,100);
  wallpreset();
  wall = createSprite(1184,576,100,100);
  wallpreset();
  wall = createSprite(1184,704,100,100);
  wallpreset();
  wall = createSprite(1184,832,100,100);
  wallpreset();
  wall = createSprite(1184,960,100,100);
  wallpreset();
  wall = createSprite(1184,1088,100,100);
  wallpreset();
  wall = createSprite(1184,1216,100,100);
  wallpreset();
  wall = createSprite(1216,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1088,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(960,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(832,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(704,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(576,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(448,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(320,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(192,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(64,1184,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(16,1216,100,100);
  wallpreset();
  wall = createSprite(16,1088,100,100);
  wallpreset();
  wall = createSprite(16,960,100,100);
  wallpreset();
  wall = createSprite(16,832,100,100);
  wallpreset();
  wall = createSprite(16,704,100,100);
  wallpreset();
  wall = createSprite(16,576,100,100);
  wallpreset();
  wall = createSprite(16,448,100,100);
  wallpreset();
  wall = createSprite(16,320,100,100);
  wallpreset();
  wall = createSprite(16,192,100,100);
  wallpreset();
  wall = createSprite(16,64,100,100);
  wallpreset();
  wall = createSprite(512,96,100,100);
  wallpreset();
  wall = createSprite(768,96,100,100);
  wallpreset();
  wall = createSprite(512,224,100,100);
  wallpreset();
  wall = createSprite(512,352,100,100);
  wallpreset();
  wall = createSprite(768,224,100,100);
  wallpreset();
  wall = createSprite(768,352,100,100);
  wallpreset();
  wall = createSprite(768,1104,100,100);
  wallpreset();
  wall = createSprite(768,976,100,100);
  wallpreset();
  wall = createSprite(768,848,100,100);
  wallpreset();
  wall = createSprite(512,1104,100,100);
  wallpreset();
  wall = createSprite(512,976,100,100);
  wallpreset();
  wall = createSprite(512,848,100,100);
  wallpreset();
  wall = createSprite(976,224,100,100);
  wallpreset();
  wall = createSprite(976,352,100,100);
  wallpreset();
  wall = createSprite(976,848,100,100);
  wallpreset();
  wall = createSprite(976,976,100,100);
  wallpreset();
  wall = createSprite(380,224,100,100);
  wallpreset();
  wall = createSprite(380,976,100,100);
  wallpreset();
  wall = createSprite(1056,400,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1056,800,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1184,400,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1184,800,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(720,400,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(720,800,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(432,400,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(432,800,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(332,146,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(332,1054,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(204,146,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(204,1054,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(76,1054,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(76,146,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(64,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(192,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(320,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(448,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(576,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(704,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(832,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(960,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1088,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(1216,1296,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(432,600,100,100);
  wall.rotation = 90
  wallpreset();
  wall = createSprite(720,600,100,100);
  wall.rotation = 90
  wallpreset();

}

